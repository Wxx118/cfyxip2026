@echo off
chcp 65001 >nul
title Geo 资源文件一键更新脚本

cd /d "%~dp0"

:: 检查并自动获取管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)


:: 设置 GitHub 加速镜像，备用https://ghproxy.net/
:: set "GH_PROXY=https://ghproxy.net/"
set "GH_PROXY=https://gh-proxy.com/"

echo ========================================
echo       开始更新 Xray 与 sing-box Geo 文件
echo ========================================
echo.

:: ---------------- 1. geoip.dat ----------------
echo [1/4] 正在下载 geoip.dat ...
curl -L -f -# --connect-timeout 10 -o "geoip.dat.tmp" "%GH_PROXY%https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat"
if %errorlevel% equ 0 (
    if exist "geoip.dat.tmp" (
        for %%A in ("geoip.dat.tmp") do (
            if %%~zA gtr 0 (
                move /y "geoip.dat.tmp" "geoip.dat" >nul
                echo     √ geoip.dat 更新成功！
            ) else (
                echo     × geoip.dat 下载文件大小为 0，已保留旧版本
                del /f /q "geoip.dat.tmp" >nul 2>&1
            )
        )
    )
) else (
    echo     × geoip.dat 下载失败，已保留旧版本
    if exist "geoip.dat.tmp" del /f /q "geoip.dat.tmp" >nul 2>&1
)
echo.

:: ---------------- 2. geosite.dat ----------------
echo [2/4] 正在下载 geosite.dat ...
curl -L -f -# --connect-timeout 10 -o "geosite.dat.tmp" "%GH_PROXY%https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat"
if %errorlevel% equ 0 (
    if exist "geosite.dat.tmp" (
        for %%A in ("geosite.dat.tmp") do (
            if %%~zA gtr 0 (
                move /y "geosite.dat.tmp" "geosite.dat" >nul
                echo     √ geosite.dat 更新成功！
            ) else (
                echo     × geosite.dat 下载文件大小为 0，已保留旧版本
                del /f /q "geosite.dat.tmp" >nul 2>&1
            )
        )
    )
) else (
    echo     × geosite.dat 下载失败，已保留旧版本
    if exist "geosite.dat.tmp" del /f /q "geosite.dat.tmp" >nul 2>&1
)
echo.

:: ---------------- 3. geoip.db ----------------
echo [3/4] 正在下载 geoip.db ...
curl -L -f -# --connect-timeout 10 -o "geoip.db.tmp" "%GH_PROXY%https://github.com/soffchen/sing-geoip/releases/latest/download/geoip.db"
if %errorlevel% equ 0 (
    if exist "geoip.db.tmp" (
        for %%A in ("geoip.db.tmp") do (
            if %%~zA gtr 0 (
                move /y "geoip.db.tmp" "geoip.db" >nul
                echo     √ geoip.db 更新成功！
            ) else (
                echo     × geoip.db 下载文件大小为 0，已保留旧版本
                del /f /q "geoip.db.tmp" >nul 2>&1
            )
        )
    )
) else (
    echo     × geoip.db 下载失败，已保留旧版本
    if exist "geoip.db.tmp" del /f /q "geoip.db.tmp" >nul 2>&1
)
echo.

:: ---------------- 4. geosite.db ----------------
echo [4/4] 正在下载 geosite.db ...
curl -L -f -# --connect-timeout 10 -o "geosite.db.tmp" "%GH_PROXY%https://github.com/soffchen/sing-geosite/releases/latest/download/geosite.db"
if %errorlevel% equ 0 (
    if exist "geosite.db.tmp" (
        for %%A in ("geosite.db.tmp") do (
            if %%~zA gtr 0 (
                move /y "geosite.db.tmp" "geosite.db" >nul
                echo     √ geosite.db 更新成功！
            ) else (
                echo     × geosite.db 下载文件大小为 0，已保留旧版本
                del /f /q "geosite.db.tmp" >nul 2>&1
            )
        )
    )
) else (
    echo     × geosite.db 下载失败，已保留旧版本
    if exist "geosite.db.tmp" del /f /q "geosite.db.tmp" >nul 2>&1
)
echo.

echo ========================================
echo               更新已完成
echo ========================================
pause